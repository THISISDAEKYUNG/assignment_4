#include <cstdio>
#include <iostream>
#include <cmath>

#include "player.h"
#include "board.h"

using std::endl;
using std::cin;
using std::cout;

class Game {
public:
    Game(int gameMode); 
    void turnPass();
    void printBoard();
    void printBombMap();
    bool move(int newRow, int newCol);
    void bomb(int bombType, int depth);
    bool checkEndCondition();

    // Mutators (setters)
    void setTurn(int nextTurn);
    void setBoard(int gameMode);

    // Accessors (getters)
    int getTurn();
    int getWinner();
    Board getBoard();
    Player getKihun();
    Player getGuard();

private:
    const int MAX_TURN = 20;
    int gameMode;
    int turn;
    Board mainGameBoard;
    Player Kihun;
    Player Guard;
    int winner;

    bool isValidMove(int newRow, int newCol, int player);
    bool isinBombRange(int bombType, int depth);
    // To change the size of tempBombMap, just modify this value.
    static const int temp_size = 273; 
    int tempBombMap[temp_size][temp_size];
};

Game::Game(int gameMode) : gameMode(gameMode) {
    Game::setTurn(0);
    Game::setBoard(gameMode);
    // Set the player initialization
    Kihun = Player(0,0);
    Guard = Player(mainGameBoard.getBoardSize()-1, mainGameBoard.getBoardSize()-1);

    for (int i = 0; i < temp_size; i++) {
        for (int j = 0; j < temp_size; j++) {
            tempBombMap[i][j] = 0;
        }
    }
    return;
}

int Game::getTurn() { 
    return turn;
}

Player Game::getGuard() {
    return Guard;
}

Player Game::getKihun() {
    return Kihun;
}

Board Game::getBoard() {
    return mainGameBoard;
}

int Game::getWinner() {
    return winner;
}

void Game::turnPass() {
    setTurn(turn + 1);
    return; 
}

void Game::printBoard() {
    /* Change this code as you need */
    /* Do not break empty blocks for foramt or endl */

    for(int i=0;i<mainGameBoard.getBoardSize();i++){
        for(int j=0;j<mainGameBoard.getBoardSize();j++){
            if (Kihun.getRow() == i && Kihun.getCol() == j){
                cout << 'K' << " ";
            }
            else if (Guard.getRow() == i && Guard.getCol() == j){
                cout << 'G' << " ";
            }
            else {
                cout << mainGameBoard.getBlockArray()[i][j].getHeight() << " ";
            }
        }
        cout << endl;
    }
}

void Game::setTurn(int nextTurn){
    // Set the turn functions
    if (nextTurn >= 0 && nextTurn <= MAX_TURN){
        turn = nextTurn;
    }
    else {
        cout << "Turn should be not negative" << endl;
    }    
    return; 
}

void Game::setBoard(int gameMode){
    // Game mode dependent
    if (gameMode == 1){
        mainGameBoard = Board(9);

    }
    else if(gameMode == 2){
        mainGameBoard = Board(15);
    }

    else if(gameMode == 3){
        mainGameBoard = Board(21);
    }

    else if(gameMode == 4){
        mainGameBoard = Board(27);
    }

    else {
        cout << "Game mode not expected number input";
    }    
    return; 
}

bool Game::isValidMove(int newRow, int newCol, int player) {
    int boardSize = mainGameBoard.getBoardSize();
    if (newRow < 0 || newCol < 0 ||
        newRow >= boardSize || newCol >= boardSize) {
            return false;
    }
    
    if (mainGameBoard.getBlockArray()[newRow][newCol].getHeight() == 0) return false;
 
    if (player == 0) {
        // Kihun
        if (Guard.getCol() == newCol && Guard.getRow() == newRow) return false;
        int a = abs(Kihun.getRow() - newRow);
        int b = abs(Kihun.getCol() - newCol);
        if (a * b != 2) return false;
 
        return true;
    }
    else if (player == 1) {
        // Guard
        if (Kihun.getCol() == newCol && Kihun.getRow() == newRow) return false;
        int a = abs(Guard.getRow() - newRow);
        int b = abs(Guard.getCol() - newCol);
        if (a + b > 2 || a == 2 || b == 2 || a + b == 0) return false;
 
        return true;
    }
    return false;
 
}

bool Game::move(int newRow, int newCol){
    /* Your code needs to start here*/
    /*
    Movement
    Kihun: Chess knight
    Guard: Directly Around (8-direction)

    Please refer to the slide for each movement

    if newRow, newCol that user gives are not available, return false
    else, move the Player and set to the newRow, newCol. Then return true
    
    */
    if ((turn % 2 == 0) && isValidMove(newRow, newCol, 0)) {
        Kihun.setRow(newRow);
        Kihun.setCol(newCol);
        return true;
    }
    else if ((turn % 2 == 1) && isValidMove(newRow, newCol, 1)) {
        Guard.setRow(newRow);
        Guard.setCol(newCol);
        return true;
}

    return false;
}

bool Game::checkEndCondition(){
    /* Your code needs to start here*/
    /* 
    You need to check conditions to decide whether the game ended or not

    1) A player reached the ground(0)
    2) A player cannot move anymore
    3) The turn reached MAX_TURN(20)

    If the both of the player reach to the end condition
    We need to compare the score

    If the game ended we need to set winner at here
    -1: Draw
    0: Kihun win
    1: Guard win
    */
    bool isKihunEnd = false, isGuardEnd = false;
    int kihun_r, kihun_c, guard_r, guard_c;
    const int kihunMoves[8][2] = {
        {-2, -1}, {-2, +1}, {-1, -2}, {-1, +2},
        {+1, -2}, {+1, +2}, {+2, -1}, {+2, +1}
    };
    
    const int guardMoves[8][2] = {
        {-1, 0}, {+1, 0}, {0, -1}, {0, +1},
        {-1, -1}, {-1, +1}, {+1, -1}, {+1, +1}
    };

    kihun_r = Kihun.getRow();
    kihun_c = Kihun.getCol();
    guard_r = Guard.getRow();
    guard_c = Guard.getCol();

    // case 2
    isKihunEnd = true;
    for (int i = 0; i < 8; i++) {
        int nr = kihun_r + kihunMoves[i][0];
        int nc = kihun_c + kihunMoves[i][1];
        if (isValidMove(nr, nc, 0)) {
            isKihunEnd = false;
            break;
        }
    }

    isGuardEnd = true;
    for (int i = 0; i < 8; i++) {
        int nr = guard_r + guardMoves[i][0];
        int nc = guard_c + guardMoves[i][1];
        if (isValidMove(nr, nc, 1)) {
            isGuardEnd = false;
            break;
        }
    }

    // case 1
    if (mainGameBoard.getBlockArray()[kihun_r][kihun_c].getHeight() == 0) {
        isKihunEnd = true;
    }
    if (mainGameBoard.getBlockArray()[guard_r][guard_c].getHeight() == 0) {
        isGuardEnd = true;
    }

    // case 3
    if (turn >= MAX_TURN) {
        isKihunEnd = true;
        isGuardEnd = true;
    }


    // is game ended? then who's the winner?
    if (!isKihunEnd && !isGuardEnd) {
        return false;
    }
    else if (isKihunEnd && isGuardEnd) {
        if (Kihun.getScore() > Guard.getScore()) {
            winner = 0;
            return true;
        }
        else if (Kihun.getScore() < Guard.getScore()){
            winner = 1;
            return true;
        }
        else {
            winner = -1;
            return true;
        }
    }
    else if (isKihunEnd) {
        winner = 1;
        return true;
    }
    else {
        winner = 0;
        return true;
    }
}

bool Game::isinBombRange(int bombType, int depth) {
    int bomb_range, r, c;
    int range = temp_size / 2;
    int size = mainGameBoard.getBoardSize() / 2;
    switch(bombType) {
        case 0: {
            bomb_range = depth;
            break;
        }
        case 1: {
            bomb_range = depth * depth - depth;
            break;
        }
        case 2: {
            bomb_range = (static_cast<int>(round(pow(3.0, depth - 1)))) / 2;
            break;
        }
        case 3: {
            bomb_range = (static_cast<int>(round(pow(3.0, depth)))) / 2;
            break;
        }
    }
    int vertices[4][2] = {
        {-bomb_range, bomb_range}, {bomb_range, bomb_range},
        {bomb_range, -bomb_range}, {-bomb_range, -bomb_range}
    };
    if (turn % 2 == 0) {
        r = Kihun.getRow() + range - size;
        c = Kihun.getCol() + range - size;
        for (int i = 0; i < 4; i++) {
            if ((r + vertices[i][0] >= range - size) && (r + vertices[i][0] <= range + size)) {
                if ((c + vertices[i][1] >= range - size) && (c + vertices[i][1] <= range + size)) {
                    return true;
                }
            }
        }
        if (((r - bomb_range <= range - size) && (r + bomb_range >= range + size)) || 
            ((c - bomb_range <= range - size) && (c + bomb_range >= range + size))) {
                return true;
        }
    }
    else {
        r = Guard.getRow() + range - size;
        c = Guard.getCol() + range - size;
        for (int i = 0; i < 4; i++) {
            if ((r + vertices[i][0] >= range - size) && (r + vertices[i][0] <= range + size)) {
                if ((c + vertices[i][1] >= range - size) && (c + vertices[i][1] <= range + size)) {
                    return true;
                }
            }
        }
        if (((r - bomb_range <= range - size) && (r + bomb_range >= range + size)) || 
        ((c - bomb_range <= range - size) && (c + bomb_range >= range + size))) {
            return true;
    }
    }
    return false;
}

void Game::bomb(int bombType, int depth){
    /* Your code needs to start here*/
    /* Implement each bomb type and modify the board accordingly*/
    /*
    bomb type 0: square 
    bomb type 1: Recursively calling left, top, right, down
    bomb type 2: Recurisvely calling but diagonal
    bomb type 3: Recursively calling left, top, right, down but, damage 1

    Please refer to the slide for each bomb type

    After bomb function, mainBoard should be modified accordingly
    Also, the score should be updated after bomb damage
    
    If depth <= 0 there would be no damage
    (It will be regarded as passing the turn)
    Don't forget to reset the bombMap to 0
    */

   if (depth <= 0) return;

    // if gameMode == Easy or Medium: Max depth would be 2
    // if ((gameMode == 1 || gameMode == 2) && depth > 2) return;

    int r, c, default_r, default_c, player;
    int size = mainGameBoard.getBoardSize();

    const int range = temp_size / 2;
    // center: [9841][9841]
    // range: 9841 +- size / 2

    if (turn % 2 == 0) {
        r = Kihun.getRow() + range - size / 2;
        c = Kihun.getCol() + range - size / 2;
        default_r = Kihun.getRow();
        default_c = Kihun.getCol();
        player = 0;

    }
    else if (turn % 2 == 1) {
        r = Guard.getRow() + range - size / 2;
        c = Guard.getCol() + range - size / 2;
        default_r = Guard.getRow();
        default_c = Guard.getCol();
        player = 1;

    }


    switch(bombType) {
        case 0: {
            // square
            if (!isinBombRange(bombType, depth)) return;
            for (int i = r - depth + 1; i <= r + depth - 1; i++) {
                for (int j = c - depth + 1; j <= c + depth - 1; j++) {
                    if (i >= 0 && i < temp_size && j >= 0 && j < temp_size) {
                        if (tempBombMap[i][j] < depth) {
                            tempBombMap[i][j] = depth;
                        }
                    }
                }
            }
            break;
        }

        case 1: {
            // Recursively calling left, top, right, down
            if (!isinBombRange(bombType, depth)) return;
            int offset = 2 * (depth - 1);
            int bombMoves[4][2] = {
                {0, offset}, {0, -offset},
                {-offset, 0}, {offset, 0}
            };
            bomb(0, depth);
            for (int i = 0; i < 4; i++) {
                if (player == 0) {
                    Kihun.setRow(default_r + bombMoves[i][0]);
                    Kihun.setCol(default_c + bombMoves[i][1]);
                }
                else {
                    Guard.setRow(default_r + bombMoves[i][0]);
                    Guard.setCol(default_c + bombMoves[i][1]);
                }
                bomb(1, depth - 1);
            }
            break;
        }
        
        case 2: {
            // Recurisvely calling but diagonal
            if (!isinBombRange(bombType, depth)) return;
            if (depth == 1) {
                bomb(0, depth);
            }
            else {
                int offset = static_cast<int>(round(pow(3.0, depth - 2)));
                int bombMoves[4][2] = {
                    {-offset, offset}, {offset, offset},
                    {offset, -offset}, {-offset, -offset}
                };
                tempBombMap[r][c] = depth;
                for (int i = 0; i < 4; i++) {
                    if (player == 0) {
                        Kihun.setRow(default_r + bombMoves[i][0]);
                        Kihun.setCol(default_c + bombMoves[i][1]);
                    }
                    else {
                        Guard.setRow(default_r + bombMoves[i][0]);
                        Guard.setCol(default_c + bombMoves[i][1]);
                    }
                    bomb(2, depth - 1);
                }
            }
            break;
        }

        case 3: {
            // Recursively calling left, top, right, down but, damage 1
            if (!isinBombRange(bombType, depth)) return;
            int offset = static_cast<int>(round(pow(3.0, depth - 1)));
            int bombMoves[4][2] = {
                {0, offset}, {0, -offset},
                {-offset, 0}, {offset, 0}
            };
            if (depth == 1) {
                for (int i = 0; i < 4; i++) {
                    if (player == 0) {
                        Kihun.setRow(default_r + bombMoves[i][0]);
                        Kihun.setCol(default_c + bombMoves[i][1]);
                    }
                    else {
                        Guard.setRow(default_r + bombMoves[i][0]);
                        Guard.setCol(default_c + bombMoves[i][1]);
                    }
                    bomb(0, 1);
                }    
            }
            else {
                for (int i = 0; i < 4; i++) {
                    if (player == 0) {
                        Kihun.setRow(default_r + bombMoves[i][0]);
                        Kihun.setCol(default_c + bombMoves[i][1]);
                    }
                    else {
                        Guard.setRow(default_r + bombMoves[i][0]);
                        Guard.setCol(default_c + bombMoves[i][1]);
                    }
                    bomb(3, depth - 1);
                }    
            }
            break;
        }

        default: {
            break;
        }
    }

    if (player == 0) {
        Kihun.setRow(default_r);
        Kihun.setCol(default_c);
    }
    else {
        Guard.setRow(default_r);
        Guard.setCol(default_c);
    }
}

void Game::printBombMap(){
    /* Change this code as you need */
    /* Do not break empty blocks for foramt or endl */
    int curBoardSize = mainGameBoard.getBoardSize();
    const int range = temp_size / 2;
    for (int i = 0; i < mainGameBoard.getBoardSize(); i++) {
        int temp_i = i + range - curBoardSize / 2;
        for (int j = 0; j < mainGameBoard.getBoardSize(); j++) {
            // tempBombMap -> BombMap
            int temp_j = j + range - curBoardSize / 2;
            mainGameBoard.setBombMap(i, j, tempBombMap[temp_i][temp_j]);

            // BombMap -> BlockArray
            if (mainGameBoard.getBombMap()[i][j] <= mainGameBoard.getBlockArray()[i][j].getHeight()) {
                if (turn % 2 == 0) {
                    Kihun.setScore(Kihun.getScore() + mainGameBoard.getBombMap()[i][j]);
                }
                else {
                    Guard.setScore(Guard.getScore() + mainGameBoard.getBombMap()[i][j]);
                }
                mainGameBoard.getBlockArray()[i][j].setHeight(
                    mainGameBoard.getBlockArray()[i][j].getHeight()
                     - mainGameBoard.getBombMap()[i][j]);    
            }
            else {
                if (turn % 2 == 0) {
                    Kihun.setScore(Kihun.getScore() + mainGameBoard.getBlockArray()[i][j].getHeight());
                }
                else {
                    Guard.setScore(Guard.getScore() + mainGameBoard.getBlockArray()[i][j].getHeight());
                }
                mainGameBoard.getBlockArray()[i][j].setHeight(0);
            }
        }
    }

    for(int i=0;i<curBoardSize; i++){
        for(int j=0;j<curBoardSize; j++){
            if (mainGameBoard.getBombMap()[i][j] > 0){
                cout << mainGameBoard.getBombMap()[i][j] << " ";
            }
            else {
                cout << 0 << " ";
            }
        }
        cout << "          " ;

        for(int j=0;j<curBoardSize; j++){
            if (Kihun.getRow() == i && Kihun.getCol() == j){
                cout << 'K' << " ";
            }
            else if (Guard.getRow() == i && Guard.getCol() == j){
                cout << 'G' << " ";
            }
            else {
                cout << mainGameBoard.getBlockArray()[i][j].getHeight() << " ";
            }
        }
        cout << endl;
    }

    for (int i = 0; i < curBoardSize; i++) {
        int temp_i = i + range - curBoardSize / 2;
        for (int j = 0; j < curBoardSize; j++) {
            int temp_j = j + range - curBoardSize / 2;
            mainGameBoard.getBombMap()[i][j] = 0;
            tempBombMap[temp_i][temp_j] = 0;
        }
    }
    return;
}


