#include <fstream>
#include "block.h"

class Board {
public:
    Board() { };
    Board(int boardSize);

    // Accessors
    int getBoardSize();
    Block** getBlockArray();
    int** getBombMap();
    // Mutators
    void setBombMap(int curRow, int curCol, int value);
    void setBlockArray(int curRow, int curCol, int value); 

private:
    int** bombMap;
    Block** blockArray;
    int boardSize;
};

Board::Board(int boardSize) : boardSize(boardSize) {
    blockArray = new Block* [boardSize];
    bombMap = new int* [boardSize];
    for (int i = 0; i < boardSize; ++i) {
        blockArray[i] = new Block[boardSize];
        bombMap[i] = new int[boardSize]();
    }
    
};

int Board::getBoardSize() {
    return boardSize;
}

Block** Board::getBlockArray() {
    return blockArray;
}

int** Board::getBombMap() {
    return bombMap;
}

void Board::setBombMap(int curRow, int curCol, int value) {
    bombMap[curRow][curCol] = value;
}

void Board::setBlockArray(int curRow, int curCol, int value) {
    blockArray[curRow][curCol].setHeight(value);
}
