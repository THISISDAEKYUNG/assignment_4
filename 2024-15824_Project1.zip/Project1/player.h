class Player {
public:
    Player(){};
    Player(int initRow, int initCol);

    // Accessors
    int getRow();
    int getCol();
    int getScore();
    // Mutators
    void setRow(int newRow);
    void setCol(int newCol);
    void setScore(int newScore);

private:
    int curRow;
    int curCol;
    int score;
};

// Player Constructor
Player::Player(int initRow, int initCol) : curRow(initRow), curCol(initCol), score(0) {
}

int Player::getRow() {
    return curRow;
}

int Player::getCol() {
    return curCol;
}

int Player::getScore() {
    return score;
}
// valid check?
void Player::setRow(int newRow) {
    curRow = newRow;
}

void Player::setCol(int newCol) {
    curCol = newCol;
}

void Player::setScore(int newScore) {
    score = newScore;
}
