#include <iostream>

#include "game.h"

using std::endl;
using std::cin;
using std::cout;

///// MAIN FUNCTIONS /////
int main(){
    cout << "Let's play Squid Game - Ice Breaker" << endl; 
    cout << "Please type the game mode that you want to play" << endl;

    int game_mode;
    cout << "Choose the game mode: " << endl;
    cout << "1. Easy Mode (9 X 9 Board)" << endl;
    cout << "2. Normal Mode (15 X 15 Board)" << endl;
    cout << "3. Hard Mode (21 X 21 Board)" << endl;
    cout << "4. Extreme Mode (27 X 27 Board)" << endl ;

    cin >> game_mode;

    switch(game_mode){
        case 1:
            cout << "Easy mode selected!!!" <<endl;
            break;
        case 2:
            cout << "Normal mode selected!!!" <<endl;
            break;
        case 3:
            cout << "Hard mode selected!!!" << endl;
            break;
        case 4:
            cout << "Extreme mode selected!!!" << endl;
            break;
        default:
            cout << "None of the mode selected" <<endl;
            cout << "Default, Easy mode selected!!!" << endl;
            game_mode = 1;
            break;
    }

    // Main game should be initialize with dependent for game_mode
    Game mainGame = Game(game_mode);
    mainGame.printBoard();
    cout << endl;
    cout << endl;

    // Main Game Loop started
    while(!mainGame.checkEndCondition()){
        int rowKihun = mainGame.getKihun().getRow();
        int colKihun = mainGame.getKihun().getCol();
        int rowGuard = mainGame.getGuard().getRow();
        int colGuard = mainGame.getGuard().getCol();

        cout << "Current Turn : " << mainGame.getTurn() << endl;
        cout << "Player Kihun location : " << rowKihun << " " << colKihun <<endl;
        cout << "Player Guard location : " << rowGuard << " " << colGuard <<endl;
        cout << "Player Kihun height : " << mainGame.getBoard().getBlockArray()[rowKihun][colKihun].getHeight() << endl;
        cout << "Player Guard height : " << mainGame.getBoard().getBlockArray()[rowGuard][colGuard].getHeight() << endl;
        cout << "Kihun : " << mainGame.getKihun().getScore() << "pts  Guard: " << mainGame.getGuard().getScore() <<"pts" << endl;

        if (mainGame.getTurn() %2 == 0) cout << "Kihun Turn!" <<endl;
        else cout << "Guard Turn!" << endl;

        int moveRow, moveCol;
        cout << "<<< Current Board Status >>>" << endl;
        mainGame.printBoard();
        cout << endl << endl;

        cout << "<<< Moving Phase >>>" << endl;

        cin >> moveRow;
        cin >> moveCol;

        int rep = 0;
        while(!mainGame.move(moveRow, moveCol)){
            rep += 1 ;
            cout << "Moving is unavailable You need to check it one more time" << endl << endl;
            cin >> moveRow;
            cin >> moveCol;
            if (rep >= 10) return 0;
        }
        
        cout << "<<< After Moving... >>>" << endl << endl;
        mainGame.printBoard();
        cout << endl << endl;

        int bombType, bombDepth;
        cout << "<<< BOMB Phase >>>" << endl;
        cout << "Set bomb type : ";
        cin >> bombType;
        cout << "Set bomb depth (Current limit : "<< (mainGame.getTurn()) <<"): ";
        cin >> bombDepth;
        rep = 0;
        while(bombDepth > (mainGame.getTurn())){
            cout << "Check depth one more time" << endl;
            cout << "Set bomb depth (Current limit : "<< (mainGame.getTurn()) <<"): ";
            cin >> bombDepth;
            if (rep >= 10) return 0;
        }

        mainGame.bomb(bombType, bombDepth);
        cout << "BOMB MAP!!! BOOM!!!" << endl << endl;
        mainGame.printBombMap();
        cout << endl << endl;
        mainGame.turnPass();
        
    }

    cout << "Game ended due to end condition. Great Job!!!" << endl;
    cout << "Kihun: " << mainGame.getKihun().getScore() << "pts  Guard: " << mainGame.getGuard().getScore() <<"pts" << endl;
    cout << "Player Kihun location: " << mainGame.getKihun().getRow() << " " << mainGame.getKihun().getCol() <<endl;
    cout << "Player Guard location: " << mainGame.getGuard().getRow() << " " << mainGame.getGuard().getCol() <<endl;
    cout << "Kihun's block height : " << mainGame.getBoard().getBlockArray()[mainGame.getKihun().getRow()][mainGame.getKihun().getCol()].getHeight() << endl;
    cout << "Guard's block height : " << mainGame.getBoard().getBlockArray()[mainGame.getGuard().getRow()][mainGame.getGuard().getCol()].getHeight() << endl;

    if(mainGame.getWinner() == -1) cout << "Draw!!!" << endl;
    else if(mainGame.getWinner() == 0) cout << "Winner Kihun!!!" <<endl;
    else if(mainGame.getWinner() == 1) cout << "Winner Guard!!!" << endl;
    return 0;
}